CREATE PROC usp_FindByExtension(@extension varchar(10))
AS
BEGIN
    SELECT id, name, CONCAT(size, 'KB') AS Size
    FROM files
    WHERE name LIKE '%' + @extension
    ORDER BY id, name, Size
END
GO

