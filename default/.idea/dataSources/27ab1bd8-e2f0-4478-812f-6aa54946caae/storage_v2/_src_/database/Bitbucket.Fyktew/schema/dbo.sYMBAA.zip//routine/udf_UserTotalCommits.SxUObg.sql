CREATE FUNCTION udf_UserTotalCommits(@username varchar(30))
    RETURNS int AS
BEGIN
    RETURN (SELECT COUNT(id)
            FROM Commits
            WHERE ContributorId = (SELECT id FROM Bitbucket.dbo.Users WHERE Username LIKE @username))
END
GO

