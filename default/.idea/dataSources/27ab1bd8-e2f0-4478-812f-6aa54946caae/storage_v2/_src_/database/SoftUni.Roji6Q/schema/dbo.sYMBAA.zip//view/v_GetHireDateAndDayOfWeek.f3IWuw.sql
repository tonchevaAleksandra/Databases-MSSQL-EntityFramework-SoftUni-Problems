CREATE VIEW v_GetHireDateAndDayOfWeek AS
SELECT HireDate, LEFT(DATENAME(DW, HireDate), 3) AS DayOfWeek
FROM Employees
GO

