CREATE   FUNCTION ucf_GetEmployeesCountByYear(@year int)
    RETURNS TABLE
AS
    RETURN
(
    SELECT COUNT(*) as Count
    FROM Employees
    WHERE DATEPART(YEAR, HireDate) = @year
)
GO

