CREATE 
 PROC
    dbo.usp_SelectEmployeesBySeniority
    (@Count int OUTPUT,
    @Year int=15,
    @MinSalary money=10000)
AS
    IF (@Year < 0) THROW 50001, 'The year should not be a negative integer',1
    SET @Count =
            (SELECT COUNT(*)
             FROM Employees
             WHERE DATEDIFF(YEAR, HireDate, GETDATE()) > @Year
               AND @MinSalary < Employees.Salary)
SELECT COUNT(*) AS ProjectCount
FROM Projects
GO

