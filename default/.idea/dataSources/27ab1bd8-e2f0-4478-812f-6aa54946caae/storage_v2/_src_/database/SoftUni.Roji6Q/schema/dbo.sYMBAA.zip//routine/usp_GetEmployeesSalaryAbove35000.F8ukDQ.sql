CREATE PROC usp_GetEmployeesSalaryAbove35000
AS
    BEGIN
        SELECT FirstName as 'First Name', LastName as 'Last Name'
        FROM Employees
        where Salary>35000
        ;
    END
GO

