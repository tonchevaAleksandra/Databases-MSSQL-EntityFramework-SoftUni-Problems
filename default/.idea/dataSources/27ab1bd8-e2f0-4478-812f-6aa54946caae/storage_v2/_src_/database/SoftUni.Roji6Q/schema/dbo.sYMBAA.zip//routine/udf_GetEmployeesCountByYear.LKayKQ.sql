CREATE   FUNCTION udf_GetEmployeesCountByYear(@year int)
    RETURNS TABLE
AS
    RETURN
(
    SELECT *
    FROM Employees
    WHERE DATEPART(YEAR, HireDate) = @year
)
GO

