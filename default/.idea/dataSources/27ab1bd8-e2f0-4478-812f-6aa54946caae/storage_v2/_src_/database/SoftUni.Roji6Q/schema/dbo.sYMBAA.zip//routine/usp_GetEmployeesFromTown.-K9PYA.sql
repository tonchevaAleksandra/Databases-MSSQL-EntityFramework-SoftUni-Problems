CREATE 
 PROC usp_GetEmployeesFromTown(@TownName nvarchar(20))
AS
SELECT FirstName AS 'First Name', LastName AS 'Last Name'
FROM Employees
         LEFT JOIN Addresses A ON A.AddressID = Employees.AddressID
         LEFT JOIN Towns T ON A.TownID = T.TownID
WHERE t.Name = @TownName
GO

