CREATE FUNCTION udf_ProjectDurationWeeks (@StartDate DATETIME,
@EndDate DATETIME)
RETURNS int Begin
    DECLARE @projectWeeks int;
    if(@EndDate is null)
    begin
        set @EndDate= getdate()
    END
    set @projectWeeks=datediff(WEEK,@StartDate,@EndDate)
    RETURN @projectWeeks
END
GO

