CREATE 
 FUNCTION udf_Pow(@Base int, @Exp int)
    RETURNS decimal
AS
BEGIN
    DECLARE @result decimal(38,0)=1;
    WHILE (@Exp > 0)
        BEGIN
            SET @result = @result * @Base;
            SET @Exp -= 1;
        END
    RETURN @result
END
GO

