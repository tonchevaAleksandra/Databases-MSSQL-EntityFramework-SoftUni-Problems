CREATE 
 FUNCTION ufn_GetSalaryLevel(@salary DECIMAL(18, 4))
RETURNS varchar(7)
    AS
BEGIN
    DECLARE @salaryLevel varchar(7);

    IF (@salary < 30000)
       set @salaryLevel= 'Low';
    ELSE
        IF (@salary <= 50000)
           set @salaryLevel='Average';
        ELSE
           set @salaryLevel='High';
    RETURN @salaryLevel
END
GO

