CREATE view v_GeetSomeConstants AS
    SELECT pi() as PI,
           getdate() as Now,
           rand() as Rand,
           SQRT(10) Sqrt10,
           power(2,10) as TwoPowerOf10
GO

