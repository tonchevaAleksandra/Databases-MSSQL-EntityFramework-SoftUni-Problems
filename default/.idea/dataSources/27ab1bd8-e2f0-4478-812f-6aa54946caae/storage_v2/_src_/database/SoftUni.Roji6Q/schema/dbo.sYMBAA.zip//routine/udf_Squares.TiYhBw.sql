CREATE 
 FUNCTION udf_Squares(@count int)
    RETURNS @squares TABLE
                     (
                         Id     int PRIMARY KEY IDENTITY,
                         Square bigint
                     )
AS
BEGIN
    DECLARE @i int=1;
    WHILE (@i <= @count)
        BEGIN
            INSERT INTO @squares(Square) VALUES (@i * @i)
            SET @i+=1;
        END
    RETURN
END
GO

