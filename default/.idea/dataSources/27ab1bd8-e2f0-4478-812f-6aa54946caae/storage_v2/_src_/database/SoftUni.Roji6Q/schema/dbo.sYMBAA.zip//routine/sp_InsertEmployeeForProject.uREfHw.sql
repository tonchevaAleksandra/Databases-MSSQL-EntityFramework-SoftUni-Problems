CREATE   PROCEDURE sp_InsertEmployeeForProject(@EmployeeId int,
                                             @ProjectId int)
AS
DECLARE @ProjectsCount int;
    SET @ProjectsCount = (SELECT COUNT(*)
                          FROM EmployeesProjects
                          WHERE EmployeeID = @EmployeeId);
    IF (@ProjectsCount >= 3)
        THROW 50001,'Employee already has 3 or more projects',1;
INSERT INTO EmployeesProjects(EmployeeID, ProjectID)
VALUES (@EmployeeId, @ProjectId);
GO

