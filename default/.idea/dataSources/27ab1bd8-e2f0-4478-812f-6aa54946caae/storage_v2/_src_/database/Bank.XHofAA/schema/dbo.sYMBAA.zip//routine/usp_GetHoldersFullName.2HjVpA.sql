CREATE PROC usp_GetHoldersFullName
AS
    SELECT concat(FirstName,' ',LastName)
FROM AccountHolders
GO

