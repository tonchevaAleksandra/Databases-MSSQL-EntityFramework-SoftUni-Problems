CREATE PROC usp_TransferFunds(@FromAccountID int, @ToAccountID int, @Amount money)
AS
    BEGIN TRANSACTION
    IF (@Amount <= 0)
        BEGIN
            --  ROLLBACK -revert the transaction that has began
            THROW 50004,'Invalid amount value.',1;
            -- return
        END
    IF ((SELECT COUNT(*)
         FROM Accounts
         WHERE Id = @FromAccountID) != 1)
        BEGIN
            THROW 50001, 'Invalid account sender.',1;
        END
    IF ((SELECT COUNT(*)
         FROM Accounts
         WHERE Id = @ToAccountID) != 1)
        BEGIN
            THROW 50002, 'Invalid account receiver.',1;
        END
    IF (SELECT Balance
        FROM Accounts
        WHERE id = @FromAccountID )< @Amount
        BEGIN
            THROW 50003,'Insufficient funds to execute this transaction.',1;
        END

UPDATE Accounts
SET Balance=Balance - @Amount
WHERE id = @FromAccountID
UPDATE Accounts
SET Balance= Balance + @Amount
WHERE id = @ToAccountID
    COMMIT
GO

