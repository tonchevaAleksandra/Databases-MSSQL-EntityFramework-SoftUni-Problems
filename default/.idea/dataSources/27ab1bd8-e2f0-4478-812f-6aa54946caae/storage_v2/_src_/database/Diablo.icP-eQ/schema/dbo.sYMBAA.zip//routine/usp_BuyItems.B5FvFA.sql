CREATE PROC usp_BuyItems(@Username nvarchar(50))
AS
BEGIN
    DECLARE @UserId int =
        (SELECT id
         FROM Users
         WHERE Username = @Username)
    DECLARE @GameId int=
        (SELECT id
         FROM Games
         WHERE Name = 'Bali')
    DECLARE @UserGameId int=
        (SELECT Id
         FROM UsersGames
         WHERE UserId = @UserId
           AND GameId = @GameId)
    DECLARE @UserGameLevel int=
            (SELECT Level FROM UsersGames WHERE Id = @UserGameId)
    DECLARE @IdCounter int = 251;

    WHILE @IdCounter <= 539
        BEGIN
            DECLARE @ItemId int = @IdCounter;
            DECLARE @ItemPrice money=
                    (SELECT Price FROM Items WHERE Id = @ItemId)
            DECLARE @ItemLevel int=
                    (SELECT MinLevel FROM Items WHERE Id = @ItemId)
            DECLARE @UserGameCash money=
                    (SELECT Cash FROM UsersGames WHERE id = @UserGameId)

            IF (@UserGameCash >= @ItemPrice AND @UserGameLevel >= @ItemLevel)
                BEGIN
                    UPDATE UsersGames
                    SET Cash-=@ItemPrice
                    WHERE Id = @UserGameId
                    INSERT INTO UserGameItems
                    VALUES (@ItemId, @UserGameId)
                END

            SET @IdCounter+=1;
            IF (@IdCounter = 300)
                BEGIN
                    SET @IdCounter = 501;
                END
        END
END
GO

