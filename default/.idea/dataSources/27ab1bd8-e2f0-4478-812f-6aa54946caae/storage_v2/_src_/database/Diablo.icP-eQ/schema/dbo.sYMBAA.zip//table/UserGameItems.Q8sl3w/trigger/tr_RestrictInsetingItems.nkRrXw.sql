CREATE TRIGGER tr_RestrictInsetingItems
    ON UserGameItems
    INSTEAD OF INSERT AS
BEGIN
    INSERT INTO UserGameItems
    SELECT i.Id, ug.Id
    FROM inserted
             JOIN UsersGames AS ug
                  ON UserGameId = ug.Id
             JOIN Items AS i
                  ON ItemId = i.id
    WHERE ug.Level >= i.MinLevel
END
GO

