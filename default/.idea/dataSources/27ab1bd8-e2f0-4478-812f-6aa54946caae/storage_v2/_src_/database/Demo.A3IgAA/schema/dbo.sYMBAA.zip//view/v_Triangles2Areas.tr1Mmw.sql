CREATE VIEW v_Triangles2Areas
as
SELECT id, (A*H)/2 as Area
FROM Triangles2
GO

