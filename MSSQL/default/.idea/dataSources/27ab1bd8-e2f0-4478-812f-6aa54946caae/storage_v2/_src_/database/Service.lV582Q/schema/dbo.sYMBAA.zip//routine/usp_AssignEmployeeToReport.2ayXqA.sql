CREATE 
 PROC usp_AssignEmployeeToReport(@EmployeeId INT, @ReportId INT)
AS
BEGIN
    DECLARE @DepartmentEmployee int =(SELECT DepartmentId
                                      FROM Service.dbo.Employees AS e
                                      WHERE e.Id = @EmployeeId);
    DECLARE @DepartmentReport int=
        (SELECT c.DepartmentId
         FROM Service.dbo.Reports AS r
                  JOIN Service.dbo.Categories C ON C.Id = r.CategoryId
         WHERE r.Id = @ReportId
        );
    IF (@DepartmentEmployee <> @DepartmentReport)
        BEGIN
            THROW 50001,'Employee doesn''t belong to the appropriate department!',1;

        END

    UPDATE Service.dbo.Reports
    SET Service.dbo.Reports.EmployeeId=@EmployeeId
    WHERE Service.dbo.Reports.Id = @ReportId
END
GO

