CREATE PROC usp_ExcludeFromSchool(@StudentId int )
AS
    BEGIN
        if(@StudentId not in (SELECT Id from Students))
        begin
            throw 50001, 'This school has no student with the provided id!',1
        END
        DELETE StudentsExams
        where StudentId=@StudentId
        DELETE StudentsSubjects
        where StudentId=@StudentId
        DELETE StudentsTeachers
        where StudentId=@StudentId
        DELETE Students
        where Id=@StudentId
    END
GO

