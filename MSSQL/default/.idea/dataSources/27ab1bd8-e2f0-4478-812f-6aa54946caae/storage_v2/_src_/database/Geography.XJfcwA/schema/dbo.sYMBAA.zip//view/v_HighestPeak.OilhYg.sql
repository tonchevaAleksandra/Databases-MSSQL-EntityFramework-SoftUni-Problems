CREATE VIEW v_HighestPeak AS 
SELECT TOP (1) *
FROM Geography.dbo.Peaks
ORDER BY Elevation DESC
GO

