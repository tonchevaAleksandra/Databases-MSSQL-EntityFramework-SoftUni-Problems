CREATE FUNCTION udf_ExamGradesToUpdate(@studentId int, @grade decimal(10, 2))
    RETURNS nvarchar(max)
    AS
BEGIN
    IF (@grade > 6.00)
        BEGIN
            RETURN 'Grade cannot be above 6.00!'
        END
    IF (@studentId NOT IN (SELECT id FROM Students))
        BEGIN
            RETURN 'The student with provided id does not exist in the school!'
        END

    DECLARE @count int=
        (SELECT COUNT(Grade)
         FROM StudentsExams
         WHERE StudentId = @studentId
           AND Grade BETWEEN @grade AND @grade + 0.50
        )

    DECLARE @FirstName nvarchar(30) =
        (SELECT FirstName
         FROM Students
         WHERE Id = @studentId)

    return
        'You have to update '+ cast(@count as nvarchar(10)) + ' grades for the student ' + @FirstName

END
GO

