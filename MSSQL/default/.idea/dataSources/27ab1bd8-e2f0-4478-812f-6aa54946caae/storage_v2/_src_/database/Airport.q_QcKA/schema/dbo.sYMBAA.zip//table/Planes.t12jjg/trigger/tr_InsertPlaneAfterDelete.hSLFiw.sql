CREATE TRIGGER tr_InsertPlaneAfterDelete
    ON Planes
    AFTER DELETE AS
BEGIN
    INSERT INTO DeletedPlanes
    SELECT d.Name, d.Seats, d.Range
    FROM deleted AS d
END
GO

