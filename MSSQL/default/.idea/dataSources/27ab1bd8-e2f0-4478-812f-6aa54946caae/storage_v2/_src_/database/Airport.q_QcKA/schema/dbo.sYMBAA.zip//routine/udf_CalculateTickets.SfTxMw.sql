CREATE 
 FUNCTION udf_CalculateTickets(@origin varchar(50),
                                    @destination varchar(50),
                                    @peopleCount int)
    RETURNS varchar(200) AS
BEGIN
    IF (@peopleCount <= 0)
        BEGIN
            RETURN 'Invalid people count!';
        END

    IF (SELECT COUNT(*)
        FROM Flights
        WHERE Origin = @origin
          AND Destination = @destination) < 1
        BEGIN

            RETURN 'Invalid flight!'

        END

    DECLARE @TotalPrice decimal(18, 2)=(SELECT SUM(price)
                                        FROM Tickets
                                                 JOIN Flights F ON F.Id = Tickets.FlightId
                                        WHERE Origin = @origin
                                          AND Destination = @destination) * @peopleCount
    RETURN 'Total price ' + CAST(@TotalPrice AS varchar(30))
END
GO

