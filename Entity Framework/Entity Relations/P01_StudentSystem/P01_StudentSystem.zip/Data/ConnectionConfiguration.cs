﻿
namespace P01_StudentSystem.Data
{
   internal static class ConnectionConfiguration
    {
        internal static string ConnectionString = @"Server=.;Database=StudentSystem;Integrated Security= true;";
    }
}
