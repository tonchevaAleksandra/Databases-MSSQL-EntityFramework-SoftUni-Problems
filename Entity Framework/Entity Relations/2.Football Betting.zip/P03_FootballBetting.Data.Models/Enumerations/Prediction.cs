﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data.Models.Enumerations
{
    public enum Prediction
    {
        Win=1,
        Lose=2,
        Draw=3
    }
}
