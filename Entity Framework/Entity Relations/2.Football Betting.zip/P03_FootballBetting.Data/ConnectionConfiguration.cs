﻿
namespace P03_FootballBetting.Data
{
   internal static class ConnectionConfiguration
    {
        internal const string ConnectionString = @"Server=.;Database=FootballBettingSystem;Integrated Security=true;";
    }
}
