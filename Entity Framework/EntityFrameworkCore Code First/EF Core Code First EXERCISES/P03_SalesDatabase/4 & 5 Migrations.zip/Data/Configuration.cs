﻿
namespace P03_SalesDatabase.Data
{
    internal static class Configuration
    {
       internal static string ConnectionString = @"Server=.;Database=SalesDatabase;Integrated Security=true";
    }
}
