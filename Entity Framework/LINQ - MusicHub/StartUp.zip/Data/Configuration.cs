﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=ALEKSANDRA\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
