﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=ALEKSANDRA\SQLEXPRESS;Database=TeisterMask;Trusted_Connection=True";
    }
}
