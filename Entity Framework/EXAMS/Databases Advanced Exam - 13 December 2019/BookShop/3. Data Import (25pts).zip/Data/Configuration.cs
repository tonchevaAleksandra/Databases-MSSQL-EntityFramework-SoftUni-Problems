﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=ALEKSANDRA\SQLEXPRESS;Database=BookShop;Trusted_Connection=True";
    }
}