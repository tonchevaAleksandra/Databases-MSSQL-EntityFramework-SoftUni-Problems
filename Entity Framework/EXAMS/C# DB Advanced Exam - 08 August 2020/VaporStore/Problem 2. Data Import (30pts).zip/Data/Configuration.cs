﻿namespace VaporStore.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=ALEKSANDRA\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
    }
}