﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _4.Add_Minion
{
   public static class Messages
    {
        public const string SuccessfullyAddedTown = "Town {0} was added to the database.";

        public const string SuccessfullyAddedVillain = "Villain {0} was added to the database.";

        public const string SuccessfullyAddedMinionToVillain = "Successfully added {0} to be minion of {1}.";
    }
}
